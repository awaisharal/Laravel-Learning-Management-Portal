

<?php $__env->startSection('meta'); ?>

<title>Instructor Dashboard | <?php echo e(config('app.name')); ?></title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
	.add-course-btn{
		display: none!important;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
<div class="col-lg-9 col-md-8 col-12">
  <!-- Page Content -->
  <div class="pb-12">
    <div class="container">
      <div id="courseForm" class="bs-stepper">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-12">
            <div class="card mb-3 ">
              <?php if(count($errors->all()) > 0): ?>
                <div class="alert alert-warning mt-5">
                  Please fill all the required fields to continue.
                </div>
                <?php if($errors->first('serverError')): ?>
                  <div class="alert alert-warning mt-5">
                    Something went wrong. Please try again later!
                  </div>
                <?php endif; ?>
              <?php endif; ?>
              <div class="card-header border-bottom px-4 py-3">
                <h4 class="mb-0">Basic Information</h4>
              </div>
              <form action="<?php echo e(route('course.update')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="mb-3">
                    <label for="courseTitle" class="form-label">Course Title</label>
                    <input id="courseTitle" name="title" class="form-control" type="text" placeholder="Course Title" value="<?php echo e($course[0]->title); ?>" />
                    <small>Write a 60 character course title.</small>
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Courses category</label>
                    <select class="selectpicker" name="category" data-width="100%">
                      <option selected value="<?php echo e($course[0]->category); ?>">Select category</option>
                      <?php if(!empty($categories)): ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                    </select>
                    <small>Help people find your courses by choosing
                      categories that represent your course.</small>
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Courses level</label>
                    <select class="selectpicker" name="level" data-width="100%">
                      <option selected value="<?php echo e($course[0]->level); ?>"><?php echo e($course[0]->level); ?></option>
                      <option value="Intermediate">Intermediate</option>
                      <option value="Beginner">Beginner</option>
                      <option value="Advance">Advance</option>
                    </select>
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Course Description</label>
                    <textarea id="" name="description" class="form-control"><?php echo e($course[0]->description); ?></textarea>
                    <small>A brief summary of your courses.</small>
                  </div>
                  <div class="mb-3">
                    <label for="" class="form-label">Video URL</label>
                    <input name='url' value="<?php echo e($course[0]->url); ?>" class="form-control" required>
                  </div>
                  <div class="mb-3">
                    <label for="" class="form-label">Tags</label>
                    <input name='tags' value='jquery, bootstrap' autofocus>
                  </div>
                  <div class="mb-3">
                    <label for="" class="form-label">Duration</label>

                    <div class="row">
                      <div class="col-md-6">
                        <div class="input-group mb-3">
                          <select name="hrs" class="form-control" required>
                            <option selected><?php echo e($course[0]->hours); ?></option>
                            <option>0</option>
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                            <option>6</option>
                            <option>7</option>
                            <option>8</option>
                            <option>9</option>
                            <option>10</option>
                            <option>11</option>
                            <option>12</option>
                            <option>13</option>
                            <option>14</option>
                            <option>15</option>
                          </select>
                          <span class="input-group-text">Hours</span>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="input-group mb-3">
                          <select name="min" class="form-control" required>
                            <?php if($course[0]->mins == ""): ?>
                              <option selected>0</option>
                            <?php else: ?>
                              <option selected><?php echo e($course[0]->mins); ?></option>
                            <?php endif; ?>
                            <option>0</option>
                            <option>5</option>
                            <option>10</option>
                            <option>15</option>
                            <option>20</option>
                            <option>25</option>
                            <option>30</option>
                            <option>35</option>
                            <option>40</option>
                            <option>45</option>
                            <option>50</option>
                            <option>55</option>
                          </select>
                          <span class="input-group-text">minutes</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="mb-3 text-right">
                    <input type="hidden" name="id" value="<?php echo e($course[0]->id); ?>" />
                    <button type="submit" class="btn btn-primary">Update</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script>
  $("#sidenav ul li#myCourses").addClass("active");
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('instructor.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Under Development\LMS\resources\views/instructor/edit-course.blade.php ENDPATH**/ ?>