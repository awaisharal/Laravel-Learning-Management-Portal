

<?php $__env->startSection('meta'); ?>

<title>Instructor Reviews | <?php echo e(config('app.name')); ?></title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
<div class="col-lg-9 col-md-8 col-12">
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('instructor.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\LMS\LMSProject\resources\views/instructor/notifications.blade.php ENDPATH**/ ?>