<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="shortcut icon" type="image/x-icon" href="/assets/images/favicon/favicon.ico">
        <base href="/">
        <?php echo $__env->yieldContent('meta'); ?>
        <?php echo $__env->make('student.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('css'); ?>
    </head>
    <body>
        <?php echo $__env->make('student.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pt-5 pb-5">
            <div class="container">
                <?php echo $__env->make('student.partials.top_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row mt-0 mt-md-4">
                    <div class="col-lg-3 col-md-4 col-12">
                        <?php echo $__env->make('student.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                        
                    </div>
                    <?php echo $__env->yieldContent('main_content'); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->make('student.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('student.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html><?php /**PATH E:\Laravel Projects\LMS\LMSProject\resources\views/student/partials/layout.blade.php ENDPATH**/ ?>