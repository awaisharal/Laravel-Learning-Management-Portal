

<?php $__env->startSection('meta'); ?>

<title>Instructor Social Profile | <?php echo e(config('app.name')); ?></title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
<div class="col-lg-9 col-md-8 col-12">
	<div class="card">
		<!-- Card header -->
		<div class="card-header">
			<h3 class="mb-0">Social Profiles</h3>
			<p class="mb-0">
				Add your social profile links in below social accounts.
			</p>
			<?php if(count($errors->all()) > 0): ?>
				<?php if($errors->first() == 'success'): ?>
					<div class="alert alert-success mt-5 mb-3">
						Social updated successfully.
					</div>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<!-- Card body -->
		<div class="card-body">
			<form action="<?php echo e(route('instructor.socialUpdate')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<div class="row mb-5">
					<div class="col-lg-3 col-md-4 col-12">
						<h5>Twitter</h5>
					</div>
					<div class="col-lg-9 col-md-8 col-12">
						<input type="text" class="form-control mb-1" placeholder="Twitter Profile URL" value="<?php echo e($user->twitter_link); ?>" name="twitter_link" />
						<small class="text-muted">Add your Twitter username (e.g. johnsmith).</small>
					</div>
				</div>
				<div class="row mb-5">
					<div class="col-lg-3 col-md-4 col-12">
						<h5>Facebook</h5>
					</div>
					<div class="col-lg-9 col-md-8 col-12">
						<input type="text" class="form-control mb-1" placeholder="Facebook Profile URL"  value="<?php echo e($user->fb_link); ?>" name="fb_link" />
						<small class="text-muted">Add your Facebook username (e.g. johnsmith).</small>
					</div>
				</div>
				<div class="row mb-5">
					<div class="col-lg-3 col-md-4 col-12">
						<h5>Github</h5>
					</div>
					<div class="col-lg-9 col-md-8 col-12">
						<input type="text" class="form-control mb-1" placeholder="Github Profile URL" value="<?php echo e($user->github_link); ?>" name="github_link" />
						<small class="text-muted">Add your github username (e.g. johnsmith).</small>
					</div>
				</div>
				<div class="row mb-5">
					<div class="col-lg-3 col-md-4 col-12">
						<h5>LinkedIn Profile URL</h5>
					</div>
					<div class="col-lg-9 col-md-8 col-12">
						<input type="text" class="form-control mb-1" placeholder="LinkedIn Profile URL " value="<?php echo e($user->linkedin_link); ?>" name="linkedin_link" />
						<small class="text-muted">Add your linkedin profile URL. (
							https://www.linkedin.com/in/example-a678vdsa)</small>
					</div>
				</div>
				<div class="row mb-3">
					<div class="col-lg-3 col-md-4 col-12">
						<h5>YouTube</h5>
					</div>
					<div class="col-lg-9 col-md-8 col-12">
						<input type="text" class="form-control mb-1" placeholder="YouTube URL" value="<?php echo e($user->youtube_link); ?>" name="youtube_link" />
						<small class="text-muted">Add your Youtube profile URL.
						</small>
					</div>
				</div>
				<div class="row">
					<div class="offset-lg-3 col-lg-6 col-12">
						<button type="submit" class="btn btn-primary">Save Social Profile</button>
					</div>
				</div>
			</form>
		</div>
	</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('instructor.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Under Development\LMS\resources\views/instructor/social-profile.blade.php ENDPATH**/ ?>